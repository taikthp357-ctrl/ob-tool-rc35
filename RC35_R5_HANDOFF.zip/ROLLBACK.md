# Rollback and identity

Keep R3 `7CA57CB283A8BBA1AB7395060F2A4C32529161DAD0B3A22F8E0699A40468EE5F` and R4 `9D716E1C4E86D7A17C67976F6C7773F835C759FFD7E38FD5496A6B05E968852D` immutable. Quarantine R5 if adverse QA. Never overwrite historical LOG/LEDGER, pending or Request state; never use production Create/Save as a rollback test. No SAP live acceptance is claimed.
