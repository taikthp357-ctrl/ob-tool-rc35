// Auto-generated MA CONTROL FG Zero-Port Data Bridge
// Generated at: 2026-10-13T23:11:24.652842
// 100% Zero-Port compliant (no open TCP sockets)
window.MA_CONTROL_DATA = {
  "version": "v1.0.0-rc52-FG",
  "app_title": "MA CONTROL — Điều hành FG",
  "zero_port_mode": true,
  "generated_at": "2026-10-13T23:11:24.652842",
  "sap_status": "SAP_GUI_AVAILABLE",
  "stock_summary": {
    "id": "NONE",
    "snapshot_time": "2026-10-13T23:11:24.652842",
    "source": "INITIAL_BASELINE",
    "total_materials": 0,
    "total_qty": 0.0
  },
  "stock_alerts": [],
  "ob_items_body_3001": [],
  "ob_items_edc_4007": [],
  "pick_orders": [],
  "bbbg_records": [],
  "waiting_cf_count": 0
};
window.OB_ITEMS_BODY = window.MA_CONTROL_DATA.ob_items_body_3001 || [];
window.OB_ITEMS_EDC = window.MA_CONTROL_DATA.ob_items_edc_4007 || [];
window.PICK_ORDERS = window.MA_CONTROL_DATA.pick_orders || [];
window.BBBG_RECORDS = window.MA_CONTROL_DATA.bbbg_records || [];
