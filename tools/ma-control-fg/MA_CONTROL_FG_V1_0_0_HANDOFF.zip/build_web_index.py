with open("G:/AI-Manager/projects/ma-control/app/templates/index.html", "r", encoding="utf-8") as f:
    content = f.read()

# Replace css links with local relative paths
content = content.replace('href="/static/css/styles.css"', 'href="./styles.css"')
content = content.replace('href="/static/css/style.css"', 'href="./style.css"')

# Replace script tags with local relative paths including data.js
old_scripts = """  <!-- JavaScript Grid Engine -->
  <script src="/static/js/app.js"></script>
  <script src="/static/js/excel_grid.js"></script>
  <script src="/static/js/pilot_sources.js"></script>"""

new_scripts = """  <!-- Zero-Port Data Bridge & JavaScript Grid Engine -->
  <script src="./data.js"></script>
  <script src="./app.js"></script>
  <script src="./excel_grid.js"></script>
  <script src="./pilot_sources.js"></script>"""

if old_scripts in content:
    content = content.replace(old_scripts, new_scripts)
else:
    content = content.replace('/static/js/app.js', './app.js')
    content = content.replace('/static/js/excel_grid.js', './excel_grid.js')
    content = content.replace('/static/js/pilot_sources.js', './pilot_sources.js')

with open("G:/AI-Manager/projects/ma-control/app/web/index.html", "w", encoding="utf-8") as f:
    f.write(content)

print("[OK] Generated app/web/index.html successfully.")
