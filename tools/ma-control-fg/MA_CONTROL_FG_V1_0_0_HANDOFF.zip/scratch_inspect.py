with open("G:/MA-Logistic-Control/app/web/dashboard.html", "r", encoding="utf-8") as f:
    text = f.read()

import re
m = re.search(r'function triggerWorkerCommand[\s\S]*?\}', text)
if m:
    print("=== triggerWorkerCommand ===")
    print(m.group(0))

m2 = re.search(r'function export[\s\S]*?\}', text)
if m2:
    print("\n=== export function ===")
    print(m2.group(0))

# Search for clipboard copy/paste
m3 = re.findall(r'navigator\.clipboard\.\w+[\s\S]*?;', text)
print("\n=== Clipboard calls ===")
for c in m3[:5]:
    print(c)
